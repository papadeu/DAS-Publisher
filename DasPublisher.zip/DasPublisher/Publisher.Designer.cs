namespace DasPublisher
{
    partial class Publisher
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Publisher));
            richTextBoxOutput = new RichTextBox();
            labelConnection = new Label();
            textBoxDasPort = new TextBox();
            labelPort = new Label();
            textBoxDasAccountID = new TextBox();
            label3 = new Label();
            textBoxPrefixText = new TextBox();
            label1 = new Label();
            textBoxWebhook = new TextBox();
            label4 = new Label();
            checkBoxWebhook = new CheckBox();
            textBoxDisclaimer = new TextBox();
            label5 = new Label();
            tabControl1 = new TabControl();
            tabPage1 = new TabPage();
            tabPage2 = new TabPage();
            label7 = new Label();
            textBoxDasUserId = new TextBox();
            numericUpDownSizePercentage = new NumericUpDown();
            labelSize = new Label();
            labelPwd = new Label();
            textBoxPassword = new TextBox();
            tabControl1.SuspendLayout();
            tabPage1.SuspendLayout();
            tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)numericUpDownSizePercentage).BeginInit();
            SuspendLayout();
            // 
            // richTextBoxOutput
            // 
            richTextBoxOutput.Dock = DockStyle.Fill;
            richTextBoxOutput.Location = new Point(3, 3);
            richTextBoxOutput.Name = "richTextBoxOutput";
            richTextBoxOutput.Size = new Size(735, 355);
            richTextBoxOutput.TabIndex = 1;
            richTextBoxOutput.Text = "";
            // 
            // labelConnection
            // 
            labelConnection.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            labelConnection.AutoSize = true;
            labelConnection.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            labelConnection.ForeColor = Color.Red;
            labelConnection.Location = new Point(0, 370);
            labelConnection.Name = "labelConnection";
            labelConnection.Size = new Size(109, 20);
            labelConnection.TabIndex = 19;
            labelConnection.Text = "not connected";
            // 
            // textBoxDasPort
            // 
            textBoxDasPort.Location = new Point(534, 28);
            textBoxDasPort.Margin = new Padding(3, 4, 3, 4);
            textBoxDasPort.Name = "textBoxDasPort";
            textBoxDasPort.Size = new Size(102, 27);
            textBoxDasPort.TabIndex = 38;
            // 
            // labelPort
            // 
            labelPort.AutoSize = true;
            labelPort.Location = new Point(416, 31);
            labelPort.Name = "labelPort";
            labelPort.Size = new Size(68, 20);
            labelPort.TabIndex = 37;
            labelPort.Text = "DAS Port";
            // 
            // textBoxDasAccountID
            // 
            textBoxDasAccountID.Location = new Point(178, 28);
            textBoxDasAccountID.Margin = new Padding(3, 4, 3, 4);
            textBoxDasAccountID.Name = "textBoxDasAccountID";
            textBoxDasAccountID.Size = new Size(164, 27);
            textBoxDasAccountID.TabIndex = 32;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(18, 35);
            label3.Name = "label3";
            label3.Size = new Size(113, 20);
            label3.TabIndex = 31;
            label3.Text = "DAS Account Id";
            // 
            // textBoxPrefixText
            // 
            textBoxPrefixText.Location = new Point(533, 121);
            textBoxPrefixText.Margin = new Padding(3, 4, 3, 4);
            textBoxPrefixText.Name = "textBoxPrefixText";
            textBoxPrefixText.Size = new Size(181, 27);
            textBoxPrefixText.TabIndex = 41;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(416, 128);
            label1.Name = "label1";
            label1.Size = new Size(75, 20);
            label1.TabIndex = 40;
            label1.Text = "Prefix text";
            // 
            // textBoxWebhook
            // 
            textBoxWebhook.Location = new Point(178, 267);
            textBoxWebhook.Margin = new Padding(3, 4, 3, 4);
            textBoxWebhook.Name = "textBoxWebhook";
            textBoxWebhook.Size = new Size(536, 27);
            textBoxWebhook.TabIndex = 45;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(18, 267);
            label4.Name = "label4";
            label4.Size = new Size(75, 20);
            label4.TabIndex = 44;
            label4.Text = "WebHook";
            // 
            // checkBoxWebhook
            // 
            checkBoxWebhook.AutoSize = true;
            checkBoxWebhook.Location = new Point(7, 227);
            checkBoxWebhook.Name = "checkBoxWebhook";
            checkBoxWebhook.Size = new Size(147, 24);
            checkBoxWebhook.TabIndex = 46;
            checkBoxWebhook.Text = "Send to webhook";
            checkBoxWebhook.UseVisualStyleBackColor = true;
            // 
            // textBoxDisclaimer
            // 
            textBoxDisclaimer.Location = new Point(178, 188);
            textBoxDisclaimer.Margin = new Padding(3, 4, 3, 4);
            textBoxDisclaimer.Name = "textBoxDisclaimer";
            textBoxDisclaimer.Size = new Size(536, 27);
            textBoxDisclaimer.TabIndex = 48;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(18, 188);
            label5.Name = "label5";
            label5.Size = new Size(108, 20);
            label5.TabIndex = 47;
            label5.Text = "Disclaimer text";
            // 
            // tabControl1
            // 
            tabControl1.Controls.Add(tabPage1);
            tabControl1.Controls.Add(tabPage2);
            tabControl1.Dock = DockStyle.Fill;
            tabControl1.Location = new Point(0, 0);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(749, 394);
            tabControl1.TabIndex = 51;
            // 
            // tabPage1
            // 
            tabPage1.Controls.Add(richTextBoxOutput);
            tabPage1.Location = new Point(4, 29);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(3);
            tabPage1.Size = new Size(741, 361);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "Executions";
            tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            tabPage2.Controls.Add(label7);
            tabPage2.Controls.Add(textBoxDasUserId);
            tabPage2.Controls.Add(numericUpDownSizePercentage);
            tabPage2.Controls.Add(labelSize);
            tabPage2.Controls.Add(labelPwd);
            tabPage2.Controls.Add(textBoxPassword);
            tabPage2.Controls.Add(textBoxDasAccountID);
            tabPage2.Controls.Add(label3);
            tabPage2.Controls.Add(labelPort);
            tabPage2.Controls.Add(textBoxDasPort);
            tabPage2.Controls.Add(label1);
            tabPage2.Controls.Add(textBoxDisclaimer);
            tabPage2.Controls.Add(textBoxPrefixText);
            tabPage2.Controls.Add(label5);
            tabPage2.Controls.Add(checkBoxWebhook);
            tabPage2.Controls.Add(textBoxWebhook);
            tabPage2.Controls.Add(label4);
            tabPage2.Location = new Point(4, 29);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(3);
            tabPage2.Size = new Size(741, 361);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "Settings";
            tabPage2.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(18, 70);
            label7.Name = "label7";
            label7.Size = new Size(88, 20);
            label7.TabIndex = 53;
            label7.Text = "DAS User Id";
            // 
            // textBoxDasUserId
            // 
            textBoxDasUserId.Location = new Point(178, 66);
            textBoxDasUserId.Margin = new Padding(3, 4, 3, 4);
            textBoxDasUserId.Name = "textBoxDasUserId";
            textBoxDasUserId.Size = new Size(164, 27);
            textBoxDasUserId.TabIndex = 54;
            // 
            // numericUpDownSizePercentage
            // 
            numericUpDownSizePercentage.Location = new Point(178, 128);
            numericUpDownSizePercentage.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
            numericUpDownSizePercentage.Name = "numericUpDownSizePercentage";
            numericUpDownSizePercentage.Size = new Size(64, 27);
            numericUpDownSizePercentage.TabIndex = 52;
            numericUpDownSizePercentage.Value = new decimal(new int[] { 1, 0, 0, 0 });
            // 
            // labelSize
            // 
            labelSize.AutoSize = true;
            labelSize.Location = new Point(18, 128);
            labelSize.Name = "labelSize";
            labelSize.Size = new Size(122, 20);
            labelSize.TabIndex = 51;
            labelSize.Text = "Size % to publish";
            // 
            // labelPwd
            // 
            labelPwd.AutoSize = true;
            labelPwd.Location = new Point(416, 66);
            labelPwd.Name = "labelPwd";
            labelPwd.Size = new Size(103, 20);
            labelPwd.TabIndex = 49;
            labelPwd.Text = "DAS Password";
            // 
            // textBoxPassword
            // 
            textBoxPassword.Location = new Point(534, 63);
            textBoxPassword.Margin = new Padding(3, 4, 3, 4);
            textBoxPassword.Name = "textBoxPassword";
            textBoxPassword.PasswordChar = '*';
            textBoxPassword.Size = new Size(180, 27);
            textBoxPassword.TabIndex = 50;
            // 
            // Publisher
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(255, 255, 192);
            ClientSize = new Size(749, 394);
            Controls.Add(labelConnection);
            Controls.Add(tabControl1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Publisher";
            Text = "DAS Publisher";
            Load += Form1_Load;
            tabControl1.ResumeLayout(false);
            tabPage1.ResumeLayout(false);
            tabPage2.ResumeLayout(false);
            tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)numericUpDownSizePercentage).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private RichTextBox richTextBoxOutput;
        private Label labelConnection;
        private TextBox textBoxDasPort;
        private Label labelPort;
        private TextBox textBoxDasAccountID;
        private Label label3;
        private TextBox textBoxPrefixText;
        private Label label1;
        private TextBox textBoxWebhook;
        private Label label4;
        private CheckBox checkBoxWebhook;
        private TextBox textBoxDisclaimer;
        private Label label5;
        private TabControl tabControl1;
        private TabPage tabPage1;
        private TabPage tabPage2;
        private Label labelPwd;
        private TextBox textBoxPassword;
        private Label labelSize;
        private NumericUpDown numericUpDownSizePercentage;
        private Label label7;
        private TextBox textBoxDasUserId;
    }
}
