using System.Text;
using Newtonsoft.Json;

namespace DasPublisher
{
    public class TextSender
    {
        public TextSender() { }

        private static HttpClient client;
        public static HttpClient Client
        {
            get
            {
                if (client == null)
                    client = new HttpClient();

                return client;
            }
        }

        
        public static async Task TrySendToWebhook(string webhookUrl, string message)
        {

            try
            {
                StringContent? contenToSend;

                if (webhookUrl.ToLower().Contains("hooks.slack.com"))
                {
                    var WebHookContent = new
                    {
                        text = message, //"This is the main content section for slack's discord", 
                    };
                    contenToSend = new StringContent(JsonConvert.SerializeObject(WebHookContent), Encoding.UTF8, "application/json");
                }
                else
                {
                    var WebHookContent = new
                    {
                        content = message, //"This is the main content section for other webhooks", 
                    };
                    contenToSend = new StringContent(JsonConvert.SerializeObject(WebHookContent), Encoding.UTF8, "application/json");
                }

                string EndPoint = webhookUrl;

                await Client.PostAsync(EndPoint, contenToSend);
            }
            catch (Exception ) { }
        }
      }
    }
