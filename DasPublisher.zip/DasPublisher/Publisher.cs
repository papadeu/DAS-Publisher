using System.Collections.Concurrent;
using System.Configuration;
using System.Security.Cryptography;
using System.Text;
using DAS.Trader.IntegrationClient.Client;
using DAS.Trader.IntegrationClient.Commands.TcpCommands;
using DAS.Trader.IntegrationClient.Response;


namespace DasPublisher
{
    public partial class Publisher : Form
    {
        private TraderClient _dasClient;
        bool _connected = false;

        string _phOpen = string.Empty;
        string _disclaimerText = string.Empty;
        string _dasAccount = string.Empty;
        string _dasPassword = string.Empty;
        string _dasUserId = string.Empty;
        
        public Publisher()
        {
            InitializeComponent();
        }

        private async void Form1_Load(object sender, EventArgs e)
        {
            SetTooltips();
           
            this.FormClosing += Publisher_FormClosing;
            ReadAppSettings();

            // Starten des Watchdog-Threads
            Thread watchdogThread = new Thread(Watchdog);
            watchdogThread.IsBackground = true;
            watchdogThread.Start();


        }

        private void SetTooltips()
        {
            ToolTip toolTip = new ToolTip();
            toolTip.SetToolTip(labelConnection, "If no connection, check account number, port id or password" + Environment.NewLine + "After change restart this program again.");

            string infoDefaultSize = "Percentage of executed size to publish";
            toolTip.SetToolTip(labelSize, infoDefaultSize);
            toolTip.SetToolTip(numericUpDownSizePercentage, infoDefaultSize);

            string infoPassword = "Password will be stored encrypted in config file";
            toolTip.SetToolTip(labelPwd, infoPassword);
            toolTip.SetToolTip(textBoxPassword, infoPassword);

            string infoPort = "Must matching the value of DAS Setup/Configuration/CMD API Port";
            toolTip.SetToolTip(labelPort, infoPort);
            toolTip.SetToolTip(textBoxDasPort, infoPort);
        }

        
        async Task ConnectToLocalDASInstance()
        {
            _connected = false;
            _phOpen = textBoxPrefixText.Text.Trim();
            _disclaimerText = textBoxDisclaimer.Text.Trim();
            _dasAccount = textBoxDasAccountID.Text.Trim();
            _dasPassword = textBoxPassword.Text.Trim();
            _dasUserId = textBoxDasUserId.Text.Trim();
            int port = 0;
            int.TryParse(textBoxDasPort.Text.Trim(), out port);
            
            while (!_connected)
            {
                string connectionText = string.Empty;
                try
                {
                    if (_dasClient != null)
                    {
                        _dasClient.Dispose();
                        _dasClient.Order -= _broker_Order;
                        _dasClient.OrderBegin -= _broker_OrderBegin;
                        _dasClient.OrderEnd -= _broker_OrderEnd;
                        _dasClient.SlOrder -= _broker_SlOrder;
                        _dasClient.SlOrderBegin -= _broker_SlOrderBegin;
                        _dasClient.SlOrderEnd -= _broker_SlOrderEnd;
                        _isStartSynchFinished = null;
                        _isInitLocate = null;
                    }

                    _dasClient = new TraderClient("127.0.0.1", port, TimeSpan.FromSeconds(10));
                    await _dasClient.ConnectAsync();

                    LoginCommand cLogin = new LoginCommand(_dasUserId, _dasPassword, _dasAccount);

                    var cmdLogin = await _dasClient.SendCommandAsync(cLogin);

                    _dasClient.Order += _broker_Order;
                    _dasClient.OrderBegin += _broker_OrderBegin;
                    _dasClient.OrderEnd += _broker_OrderEnd;

                    _dasClient.SlOrder += _broker_SlOrder;
                    _dasClient.SlOrderBegin += _broker_SlOrderBegin;
                    _dasClient.SlOrderEnd += _broker_SlOrderEnd;

                    _connected = cmdLogin.Success;
                }
                catch (Exception ex)
                {
                    _connected = false;
                    ShowConnectionState();
                    await Task.Delay(30000);
                }
                ShowConnectionState();
            }
        }

        private void ShowConnectionState()
        {
            // =>> logging connection status here
            string connectionText = _connected ? "connected" : "not connected";
            Color connectionColor = _connected ? Color.Green : Color.Red;
            Color backColor = _connected ? SystemColors.Control : Color.FromArgb(255, 255, 192);
            if (labelConnection.InvokeRequired)
            {
                labelConnection.BeginInvoke((MethodInvoker)(() => { labelConnection.Text = connectionText; }));
                labelConnection.BeginInvoke((MethodInvoker)(() => { labelConnection.ForeColor = connectionColor; }));
                labelConnection.BeginInvoke((MethodInvoker)(() => { this.BackColor = backColor; }));
            }
            else
            {
                labelConnection.Text = connectionText;
                labelConnection.ForeColor = connectionColor;
                this.BackColor = backColor;
            }
        }


        #region connection management with watch dog
        private void Watchdog()
        {
            //only for init, until asynch conn created
            ConnectToLocalDASInstance();

            while (true)
            {
                Thread.Sleep(30000); // Überprüfung alle n Sekunden

                EchoCommand exho = new EchoCommand();
                var alive = _dasClient.SendCommandAsync(exho).Result;
                if (!alive.Success)
                {
                    ConnectToLocalDASInstance().GetAwaiter().GetResult(); //wait until connects again
                }
            }
        }
        #endregion


        #region initialization helpers
        bool? _isInitLocate = null;
        private void _broker_SlOrderBegin(object? sender, ResponseEventArgs e)
        {
            if (_isInitLocate != null)
                return;
            _isInitLocate = true; }

        private void _broker_SlOrderEnd(object? sender, ResponseEventArgs e)
        {   _isInitLocate = false; }

        bool? _isStartSynchFinished = null;
        private void _broker_OrderEnd(object? sender, ResponseEventArgs e)
        {   _isStartSynchFinished = true; }

        private void _broker_OrderBegin(object? sender, ResponseEventArgs e)
        {
            if (_isStartSynchFinished != null)
                return;
            _isStartSynchFinished = false;
        }

        #endregion

        ConcurrentDictionary<string, KeyValuePair<int, bool>> _availableLocates = new ConcurrentDictionary<string, KeyValuePair<int, bool>>();
        private void _broker_SlOrder(object? sender, ResponseEventArgs e)
        {
            if ((bool)_isInitLocate)
                return;

            string status = e.Parameters[6].ToLower();
            if (status == "located")
            {
                string ticker = e.Parameters[1];
                int initialAmount = Convert.ToInt32(e.Parameters[2]);
                int leftAmount = Convert.ToInt32(e.Parameters[3]);
                int locatedAmount = Convert.ToInt32(e.Parameters[4]);

                bool locatedEntirely = leftAmount == 0;

                int previousAmount = 0;
                if (_availableLocates.ContainsKey(ticker))
                    previousAmount = _availableLocates[ticker].Key;

                _availableLocates[ticker] = new KeyValuePair<int, bool>(previousAmount + locatedAmount, locatedEntirely);

                if (locatedEntirely)
                {
                    string percentageAmount = ComputePercentageSize(initialAmount.ToString());
                    string message = $"{_phOpen} LOC {ticker} {percentageAmount} | {DateTime.Now.ToLongTimeString()}";
                    SendMessage(message);
                }
            }

        }

        Queue<KeyValuePair<Guid, string>> _executions = new Queue<KeyValuePair<Guid, string>>(100);

        private void _broker_Order(object? sender, ResponseEventArgs e)
        {
            if ((bool)!_isStartSynchFinished) { return; }

            string actionId = string.Empty;
            if (e != null && e.Parameters?.Length > 10 && !string.IsNullOrEmpty(e.Parameters[10]))
                actionId = e.Parameters[10];

            var marker = new KeyValuePair<Guid, string>(e.CorrelationId, actionId);
            if (_executions.Contains(new KeyValuePair<Guid, string>(e.CorrelationId, actionId))) { return; }

            _executions.Enqueue(marker);

            //dt = DateTime.Now;
            string message = e.Message;
            if (!string.IsNullOrEmpty(message))
            {
                string[] splitted = message.Split(" ", StringSplitOptions.TrimEntries);
                if (splitted != null && splitted.Any() && splitted.Contains("Executed"))
                {
                    //example 284721 360 VCIG S L 1 0 0 0.34 SMRTL Executed 06:28:28 284720
                    //example 284820 362     VCIG S                 L              999      999 0      1 SMAT Sending 06:33:53 0
                    //        id     refid   sym  side (SS S B)     type (LMT(MKT) amount   remaining

                    string ticker = splitted[3];
                    string transactionType = splitted[4];
                    string orderType = splitted[5];
                    string amount = splitted[6];
                    string amountOrderRemaining = splitted[7];
                    string percentageAmount = ComputePercentageSize(amount);

                    message = $"{_phOpen} {transactionType} {ticker} {percentageAmount} | {DateTime.Now.ToLongTimeString()}";
                    SendMessage(message);
                }
            }
        }

        private string ComputePercentageSize(string amount)
        {
            string ret = "0";
            long lAmount = 0;
            long.TryParse(amount, out lAmount);

            decimal amountPercentage = lAmount * (decimal)numericUpDownSizePercentage.Value / 100;
            
            if (amountPercentage > 10)
                amountPercentage = Math.Round(amountPercentage);
            else
                amountPercentage = Math.Round(amountPercentage, 1);

            ret = amountPercentage.ToString();
            return ret;
        }

        private void SendMessage(string text)
        {
            try
            {
                string separatorLine = "----------";
                var msg = text.Trim() + Environment.NewLine + _disclaimerText + Environment.NewLine +separatorLine + Environment.NewLine;
                

                if(checkBoxWebhook.Checked)
                    TextSender.TrySendToWebhook(textBoxWebhook.Text.Trim(), msg);

                void Update()
                {
                    richTextBoxOutput.AppendText(msg);
                }

                if (richTextBoxOutput.InvokeRequired)
                    richTextBoxOutput.BeginInvoke((Action)Update);
                else
                    Update();
            }
            catch (Exception ex)
            { MessageBox.Show("Error by message receiving. Please take screenshot and restart this application.\n " + ex.ToString()); }
        }

        #region settings
        private void Publisher_FormClosing(object? sender, FormClosingEventArgs e)
        {
            Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            config.AppSettings.Settings["DasAccountId"].Value = textBoxDasAccountID.Text.Trim();
            config.AppSettings.Settings["DasPort"].Value = textBoxDasPort.Text.Trim();
            config.AppSettings.Settings["DasUserId"].Value = textBoxDasUserId.Text.Trim();
            config.AppSettings.Settings["DasPassword"].Value = Protect(textBoxPassword.Text.Trim());
            config.AppSettings.Settings["PrefixText"].Value = textBoxPrefixText.Text.Trim();
            config.AppSettings.Settings["DisclaimerText"].Value = textBoxDisclaimer.Text.Trim();
            config.AppSettings.Settings["WebHook"].Value = textBoxWebhook.Text.Trim();

            config.AppSettings.Settings["SizePercentage"].Value = numericUpDownSizePercentage.Value.ToString();
            config.AppSettings.Settings["SendToWebhook"].Value = checkBoxWebhook.Checked.ToString();
            
            config.Save();

            this.FormClosing -= Publisher_FormClosing;

            // Disconnect from DAS
            _dasClient?.Dispose();
        }

        private void ReadAppSettings()
        {
            textBoxDasAccountID.Text = ConfigurationManager.AppSettings["DasAccountId"];
            textBoxDasPort.Text = ConfigurationManager.AppSettings["DasPort"];
            textBoxDasUserId.Text = ConfigurationManager.AppSettings["DasUserId"];
            string pwdEncrypted = ConfigurationManager.AppSettings["DasPassword"];
            textBoxPassword.Text = Unprotect(pwdEncrypted);

            textBoxPrefixText.Text = ConfigurationManager.AppSettings["PrefixText"];
            textBoxDisclaimer.Text = ConfigurationManager.AppSettings["DisclaimerText"];
            textBoxWebhook.Text = ConfigurationManager.AppSettings["WebHook"];

            int sizePercentage = 1;
            int.TryParse(ConfigurationManager.AppSettings["SizePercentage"], out sizePercentage);
            numericUpDownSizePercentage.Value = sizePercentage;

            bool sendToWekhook = false;
            bool.TryParse(ConfigurationManager.AppSettings["SendToWebhook"], out sendToWekhook);
            checkBoxWebhook.Checked = sendToWekhook; 

        }

        public static string Protect(string plainText)
        {
            byte[] bytes = Encoding.UTF8.GetBytes(plainText);
            byte[] encrypted = ProtectedData.Protect(
                bytes,
                null,
                DataProtectionScope.CurrentUser);

            return Convert.ToBase64String(encrypted);
        }

        public static string Unprotect(string encryptedText)
        {
            if (string.IsNullOrWhiteSpace(encryptedText))
                return encryptedText;

            try
            {
                byte[] bytes = Convert.FromBase64String(encryptedText);

                byte[] decrypted = ProtectedData.Unprotect(
                    bytes,
                    null,
                    DataProtectionScope.CurrentUser);

                return Encoding.UTF8.GetString(decrypted);
            }
            catch (FormatException)
            {
                // Not valid Base64
                return encryptedText;
            }
            catch (CryptographicException)
            {
                // Valid Base64, but not a DPAPI-encrypted value
                return encryptedText;
            }
        }

        #endregion

    }
}
